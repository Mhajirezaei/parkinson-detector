from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route("/consult", methods=["POST"])
def consult():
    data = request.get_json()
    balance = data.get("balance_score")

    if balance is None:
        return jsonify({"error": "لطفاً مقدار میانگین تعادل را وارد کنید"}), 400

    if balance >= 8:
        level = "عالی"
        nutrition = "رژیم متنوع با میوه، سبزیجات، و چربی‌های سالم را ادامه دهید."
        exercise = "پیاده‌روی، یوگا یا حرکات سبک برای حفظ وضعیت فعلی توصیه می‌شود."
    elif balance >= 5:
        level = "متوسط"
        nutrition = "از مصرف غذاهای سنگین، قند و چربی زیاد پرهیز کرده و غذاهای غنی از امگا ۳ مصرف کنید."
        exercise = "تمرین‌های تعادل، تای‌چی یا تمرینات کششی سبک انجام دهید."
    else:
        level = "ضعیف"
        nutrition = "غذاهای نرم، غنی از فیبر، و راحت‌الهضم مصرف کنید. از مصرف نمک و شکر زیاد دوری کنید."
        exercise = "با فیزیوتراپیست تمرین کنید و از تمرین‌های خطرناک خودداری نمایید."

    return jsonify({
        "level": level,
        "nutrition_advice": nutrition,
        "exercise_advice": exercise,
        "note": "این مشاوره عمومی است و جایگزین نظر پزشک نمی‌شود."
    })
if __name__ == '__main__':
    app.run(debug=True)
