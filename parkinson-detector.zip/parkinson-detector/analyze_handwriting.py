import cv2
import numpy as np

def analyze_handwriting(image_path):
    image = cv2.imread(image_path, 0)  # Grayscale
    if image is None:
        return {"error": "تصویر خوانده نشد"}

    blurred = cv2.GaussianBlur(image, (5, 5), 0)
    edges = cv2.Canny(blurred, 50, 150)

    contours, _ = cv2.findContours(edges.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    avg_height = 0
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        avg_height += h

    avg_height = avg_height / len(contours) if contours else 0

    result = {
        "contour_count": len(contours),
        "avg_letter_height": round(avg_height, 2)
    }

    if avg_height < 10:
        result["comment"] = "اندازه حروف بسیار کوچک است، ممکن است نشانه‌ای از Micrographia باشد."
    else:
        result["comment"] = "اندازه حروف در محدوده نرمال است."

    return result
