import os
import pickle
import librosa
import numpy as np
from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
import cv2

app = Flask(__name__)

# 🔹 مدل صدا (پیکل)
model = pickle.load(open('model/model.pkl', 'rb'))

# 🔹 پوشه‌ها
AUDIO_UPLOAD_FOLDER = 'data/uploads'
HANDWRITING_UPLOAD_FOLDER = 'uploads/handwriting'
BALANCE_UPLOAD_FOLDER = 'uploads/balance_videos'
os.makedirs(AUDIO_UPLOAD_FOLDER, exist_ok=True)
os.makedirs(HANDWRITING_UPLOAD_FOLDER, exist_ok=True)
os.makedirs(BALANCE_UPLOAD_FOLDER, exist_ok=True)

app.config['AUDIO_UPLOAD_FOLDER'] = AUDIO_UPLOAD_FOLDER
app.config['HANDWRITING_UPLOAD_FOLDER'] = HANDWRITING_UPLOAD_FOLDER
app.config['BALANCE_UPLOAD_FOLDER'] = BALANCE_UPLOAD_FOLDER

# 🔹 تحلیل تصویر دست‌خط
def analyze_handwriting(image_path):
    image = cv2.imread(image_path, 0)  # خاکستری
    if image is None:
        return {"error": "تصویر خوانده نشد"}

    blurred = cv2.GaussianBlur(image, (5, 5), 0)
    edges = cv2.Canny(blurred, 50, 150)
    contours, _ = cv2.findContours(edges.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    avg_height = 0
    for cnt in contours:
        _, _, _, h = cv2.boundingRect(cnt)
        avg_height += h
    avg_height = avg_height / len(contours) if contours else 0

    result = {
        "contour_count": len(contours),
        "avg_letter_height": round(avg_height, 2)
    }

    if avg_height < 10:
        result["comment"] = "اندازه حروف بسیار کوچک است، ممکن است نشانه‌ای از Micrographia باشد."
    else:
        result["comment"] = "اندازه حروف در محدوده نرمال است."

    return result

# 🔹 الگوریتم ساده تشخیص تعادل (بر اساس Optical Flow)
def analyze_balance(video_path):
    cap = cv2.VideoCapture(video_path)
    ret, old_frame = cap.read()
    if not ret:
        cap.release()
        return {"error": "ویدئو خوانده نشد."}

    old_gray = cv2.cvtColor(old_frame, cv2.COLOR_BGR2GRAY)
    p0 = cv2.goodFeaturesToTrack(old_gray, mask=None, maxCorners=100, qualityLevel=0.3, minDistance=7, blockSize=7)
    if p0 is None:
        cap.release()
        return {"error": "نقاطی برای دنبال کردن پیدا نشد."}

    movement_magnitudes = []

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        p1, st, err = cv2.calcOpticalFlowPyrLK(old_gray, frame_gray, p0, None)

        good_new = p1[st == 1]
        good_old = p0[st == 1]

        movement = good_new - good_old
        distances = np.linalg.norm(movement, axis=1)
        movement_magnitudes.extend(distances)

        old_gray = frame_gray.copy()
        p0 = good_new.reshape(-1, 1, 2)

    cap.release()

    if len(movement_magnitudes) == 0:
        return {"comment": "تحلیل تعادل امکان‌پذیر نبود."}

    avg_movement = np.mean(movement_magnitudes)
    threshold = 2.0  # آستانه لرزش زیاد

    if avg_movement > threshold:
        return {
            "average_movement": round(avg_movement, 2),
            "comment": "حرکات و لرزش زیاد است، ممکن است نشانه‌ای از اختلال تعادل باشد."
        }
    else:
        return {
            "average_movement": round(avg_movement, 2),
            "comment": "تعادل مناسب به نظر می‌رسد."
        }


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    audio_result = None
    handwriting_result = None

    # 🔹 پردازش فایل صوتی
    if 'file' in request.files:
        file = request.files['file']
        if file and file.filename != '':
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['AUDIO_UPLOAD_FOLDER'], filename)
            file.save(filepath)

            try:
                audio, sr = librosa.load(filepath)
                mfccs = librosa.feature.mfcc(y=audio, sr=sr, n_mfcc=22)
                features = np.mean(mfccs.T, axis=0).reshape(1, -1)
                prediction = model.predict(features)
                audio_result = 'مبتلا به پارکینسون' if prediction[0] == 1 else 'سالم'
            except Exception as e:
                audio_result = f'خطا در پردازش صدا: {str(e)}'

    # 🔹 پردازش تصویر دست‌خط
    if 'handwriting' in request.files:
        handwriting_file = request.files['handwriting']
        if handwriting_file and handwriting_file.filename != '':
            handwriting_name = secure_filename(handwriting_file.filename)
            handwriting_path = os.path.join(app.config['HANDWRITING_UPLOAD_FOLDER'], handwriting_name)
            handwriting_file.save(handwriting_path)
            handwriting_result = analyze_handwriting(handwriting_path)

    return render_template('index.html', audio_result=audio_result, handwriting_result=handwriting_result)

@app.route('/check_balance', methods=['POST'])
def check_balance():
    if 'video' not in request.files:
        return 'ویدیو ارسال نشده!'

    video = request.files['video']
    if video.filename == '':
        return 'فایلی انتخاب نشده!'

    filename = secure_filename(video.filename)
    filepath = os.path.join(app.config['BALANCE_UPLOAD_FOLDER'], filename)
    video.save(filepath)

    balance_result = analyze_balance(filepath)
    if 'error' in balance_result:
        return balance_result['error']
    else:
        return f"میانگین جابجایی: {balance_result['average_movement']}\nوضعیت: {balance_result['comment']}"

if __name__ == '__main__':
    app.run(debug=True)
