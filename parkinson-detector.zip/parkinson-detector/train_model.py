import os
import numpy as np
import librosa
import pickle
from sklearn.ensemble import RandomForestClassifier

# مسیر داده‌ها
data_dir = 'data/audio'
X = []
y = []

# استخراج ویژگی از صداها
for file in os.listdir(data_dir):
    if file.endswith('.wav'):
        label = 1 if 'parkinson' in file else 0
        path = os.path.join(data_dir, file)
        audio, sr = librosa.load(path)
        mfccs = librosa.feature.mfcc(y=audio, sr=sr, n_mfcc=22)
        features = np.mean(mfccs.T, axis=0)
        X.append(features)
        y.append(label)

# آموزش مدل
model = RandomForestClassifier()
model.fit(X, y)

# ذخیره مدل
os.makedirs('model', exist_ok=True)
with open('model/model.pkl', 'wb') as f:
    pickle.dump(model, f)

print("✅ مدل ذخیره شد.")
